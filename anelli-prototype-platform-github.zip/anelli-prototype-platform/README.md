# Anelli Prototype Platform

A working collection of typography, graphic, sound and interaction experiments.

## Included experiments

- Kinetic Composer
- Particle Type Distorter
- Font Drawing
- Noise-Built Type
- GP888 Drum Machine
- ASCII Kinetic Typo Machine

## Requirements

- Node.js 22.13 or newer
- pnpm 11

## Run locally

```bash
pnpm install
pnpm dev
```

Open the local address printed in the terminal.

## Production build

```bash
pnpm build
```

The project uses Vinext, React, TypeScript, Tailwind CSS and Cloudflare's Vite tooling.

## Project structure

- `app/` — platform routes and experiment pages
- `components/` — interactive React experiments and shared interface
- `public/experiments/` — imported standalone experiment builds
- `MANUAL.md` — working protocol for ChatGPT-assisted development

## Working protocol

The repository is the source of truth. Develop changes in a branch, review a preview deployment, and merge approved work into `main` for production.

Useful commands are documented in `MANUAL.md`, including `START`, `OPEN`, `ITERATE`, `FORK`, `PREVIEW`, `KEEP`, and `PUBLISH`.

## Hosting

The codebase produces a Cloudflare-compatible Vinext build. Connect the GitHub repository to the chosen Cloudflare deployment workflow, then attach the final custom domain or subdomain there.

Do not commit local environment files, build output, dependency folders or credentials.
